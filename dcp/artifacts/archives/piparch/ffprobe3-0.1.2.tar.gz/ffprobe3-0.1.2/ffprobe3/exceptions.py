"""
Custom exceptions file
"""


class FFProbeError(Exception):
    pass
